export class Counsel {
    name: string;
    phone: string;
    date: string;
    option: string;
    text: string;
    amount: number;
    payment: string;
    RVstatus: string;
    paymentStatus : string;
    merchant_uid : string;
    paymentData : string[];
}